import javafx.application.Application;
import javafx.scene.control.Alert;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.input.*;

public class TelaLogin extends Application
{		
	Biblioteca b = new Biblioteca();
	public static void main(String[] args)
	{
		Application.launch(args);
	}

	@Override
	public void start(Stage stage)
	{
		// Criar os campos de texto
		TextField txtLogin = new TextField();
		PasswordField txtSenha = new PasswordField();

		// Definir o tamanho dos campos de texto
		txtLogin.setPrefColumnCount(10);
		txtSenha.setPrefColumnCount(10);	

		// Criar bot�es
		Button btnLogin = new Button("Login");
		Button btnSair = new Button("Sair");
		Button btnSobre = new Button("Sobre");

		// Definir largura dos bot�es
		btnLogin.setMinWidth(150);
		btnSair.setMinWidth(150);
		btnSobre.setMinWidth(150);

		// Adicionar evento aos bot�es
		// Bot�o Login
		btnLogin.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				UsuarioVO u = new UsuarioVO();
				Alert dialogoResultado = new Alert(Alert.AlertType.INFORMATION);
				dialogoResultado.setHeaderText("Login");
				try {
					if (Biblioteca.testaLogin(txtLogin.getText(), txtSenha.getText()) == true) {											
						u = UsuarioDAO.consultaLogin(txtLogin.getText());
					}						            				
					else
					{
						dialogoResultado.setContentText("Nome de usu�rio e/ou senha inv�lido(s)");
						dialogoResultado.showAndWait();						
						return;
					}
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}				
				//Abrir tela principal
				Stage menuStage = new Stage();
				TelaPrincipal p = new TelaPrincipal(u);
				p.start(menuStage);				
				menuStage.show();				
			}
		});	

		// Bot�o Sair
		btnSair.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				stage.close();
			}
		});		

		// Bot�o Sobre
		btnSobre.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				Alert dialogoResultado = new Alert(Alert.AlertType.INFORMATION);
				dialogoResultado.setHeaderText("Sobre");
				dialogoResultado.setContentText("Cintia\nMichele\nWagner");
				dialogoResultado.showAndWait();
			}
		});	

		// Campo senha
		txtSenha.setOnKeyPressed(new EventHandler<KeyEvent>()
	    {
	        @Override
	        public void handle(KeyEvent ke)
	        {
	            if (ke.getCode().equals(KeyCode.ENTER))
	            {
	                btnLogin.fire();
	            }
	        }
	    });



		// Criar o gridpane
		GridPane root = new GridPane();

		// Definir alinhamento
		root.setAlignment(Pos.CENTER);;

		// Definir o espa�amento horizontal
		root.setHgap(10);

		// Definir o espa�amento vertical
		root.setVgap(5);

		// Adicionar labels e campos de texto ao gridpane				
		root.addRow(0, new Label("Login:"), txtLogin);
		root.addRow(1, new Label("Senha:"), txtSenha);
		root.addRow(2, new Label(""), btnLogin);
		root.addRow(3, new Label(""), btnSair);
		root.addRow(4, new Label(""), btnSobre);

		// Definir tamanho do grid pane
		root.setMinSize(640, 480);

		/* 
		 * Set the padding of the GridPane
		 * Set the border-style of the GridPane
		 * Set the border-width of the GridPane
		 * Set the border-insets of the GridPane
		 * Set the border-radius of the GridPane
		 * Set the border-color of the GridPane
		 */
		root.setStyle("-fx-padding: 10;" +
				"-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-insets: 5;" +
				"-fx-border-radius: 5;" +
				"-fx-border-color: silver;");

		// Criar a scene
		Scene scene = new Scene(root);
		// Adicionar scene ao stage
		stage.setScene(scene);
		// Definir t�tulo
		stage.setTitle("Padaria - Login");
		// Mostrar tela
		stage.show();		
	}	
}