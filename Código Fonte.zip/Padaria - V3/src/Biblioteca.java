import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

import javafx.scene.control.Alert;

public class Biblioteca {
	public static class ConexaoBD {
	    public static Connection getConexao() {
		Connection conexao = null;        
	        try {	
	        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		            conexao = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"
		                    + "database=Padaria;" +
	                              "user=sa;" +
	                              "password=123456;");		            
		        
		        } catch (Exception erro) {
		            erro.printStackTrace();
		        }
	        return conexao;
	    }   
	}
	
	public static boolean testaLogin (String usuario, String senha) {		
		try {
		Connection conexao = ConexaoBD.getConexao();		
		String SPsql = "{call dbo.sp_Login (?,?,?)}";   // for stored proc taking 2 parameters
		
		CallableStatement ps = conexao.prepareCall(SPsql);		
		ps.setString(1, usuario);		
		ps.setString(2, senha);
		ps.registerOutParameter(3, Types.VARCHAR);
		ps.execute();
		String resultado = ps.getString(3);			
		if (resultado.equals("0"))
			return false;
		else 
			return true;
		}
		catch  (Exception e) {
			return false;
		}		
	}
	
	
	//m�todo para tratar exce��es
	public static void trataErro (Exception ex) {
		Alert dialogoResultado = new Alert(Alert.AlertType.ERROR);	
		if(ex instanceof SQLException)
			dialogoResultado.setHeaderText("Erro no banco de dados");
		else
			dialogoResultado.setHeaderText("Erros diversos");
		dialogoResultado.setContentText(ex.getMessage());
		dialogoResultado.showAndWait();			
	}
	
	//m�todo para tratar mensagens
	public static void trataErro (String s) {
		Alert dialogoResultado = new Alert(Alert.AlertType.WARNING);		
		dialogoResultado.setHeaderText("Falha no preenchimento");
		dialogoResultado.setContentText(s);
		dialogoResultado.showAndWait();			
	}
}
