import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.regex.Pattern;

import javafx.collections.ObservableList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.cell.PropertyValueFactory;

public class TelaPrincipal extends Application
{		
	// criamos o painel
	TabPane painelAbas = new TabPane();

	// criando paineis de abas, o construtor recebe o nome da aba
	Tab abaUsuarios = new Tab("Usu�rios");				
	Tab abaClientes = new Tab("Clientes");
	Tab abaProdutos = new Tab("Produtos");				
	Tab abaPedidos = new Tab("Pedidos");	

	boolean navegacaoUsuarios;
	boolean edicaoUsuarios;
	boolean navegacaoClientes;
	boolean edicaoClientes;
	boolean navegacaoProdutos;
	boolean edicaoProdutos;
	boolean navegacaoPedidos;
	boolean edicaoPedidos;

	//criar um UsuarioVO para o usu�rio logado
	UsuarioVO uLogado = new UsuarioVO();

	//criar um UsuarioVO tempor�rio
	UsuarioVO uTemp = new UsuarioVO();

	// Criar os campos de texto e combobox de usuario
	TextField txtIDUsuarios = new TextField();
	TextField txtNomeUsuarios = new TextField();
	MaskedTextField txtTelefoneUsuarios = new MaskedTextField("(##)#####-####");	
	TextField txtEmailUsuarios = new TextField();
	ComboBox<String> cbxFuncaoUsuarios = new ComboBox<>();
	ComboBox<String> cbxTipoUsuarioUsuarios = new ComboBox<>();
	TextField txtLoginUsuarios = new TextField();
	PasswordField txtSenhaUsuarios = new PasswordField();

	// Criar bot�es da aba usu�rios
	Button btnIncluirUsuarios = new Button("Incluir");
	Button btnAlterarUsuarios = new Button("Alterar");
	Button btnExcluirUsuarios = new Button("Excluir");
	Button btnSalvarUsuarios = new Button("Salvar");
	Button btnCancelarUsuarios = new Button("Cancelar");
	Button btnPrimeiroUsuarios = new Button("<<");
	Button btnAnteriorUsuarios = new Button("<");
	Button btnProximoUsuarios = new Button(">");
	Button btnUltimoUsuarios = new Button(">>");
	//Button btnPesquisarUsuarios = new Button("Pesquisar");

	//criar um ClienteVO tempor�rio
	ClienteVO cTemp = new ClienteVO();

	// Criar os campos de texto e combobox de clientes
	TextField txtIDClientes = new TextField();
	TextField txtNomeClientes = new TextField();
	MaskedTextField txtTelefoneClientes = new MaskedTextField("(##)#####-####");	
	TextField txtEmailClientes = new TextField();
	TextField txtEnderecoClientes = new TextField();
	TextField txtNumeroClientes = new TextField();
	TextField txtComplementoClientes = new TextField();
	TextField txtBairroClientes = new TextField();
	ComboBox<String> cbxCidadeClientes = new ComboBox<>();
	MaskedTextField txtCepClientes = new MaskedTextField("#####-###");

	// Criar bot�es da aba clientes
	Button btnIncluirClientes = new Button("Incluir");
	Button btnAlterarClientes = new Button("Alterar");
	Button btnExcluirClientes = new Button("Excluir");
	Button btnSalvarClientes = new Button("Salvar");
	Button btnCancelarClientes = new Button("Cancelar");
	Button btnPrimeiroClientes = new Button("<<");
	Button btnAnteriorClientes = new Button("<");
	Button btnProximoClientes = new Button(">");
	Button btnUltimoClientes = new Button(">>");
	//Button btnPesquisarClientes = new Button("Pesquisar");

	//criar um ProdutoVO tempor�rio
	ProdutoVO pTemp = new ProdutoVO();

	// Criar os campos de texto e combobox da aba Produtos
	TextField txtIDProdutos = new TextField();
	TextField txtDescricaoProdutos = new TextField();	
	ComboBox<String> cbxCategoriaProdutos = new ComboBox<>();
	TextField txtValorProdutos = new TextField();
	TextField txtQuantidadeProdutos = new TextField();
	ComboBox<String> cbxInventarioProdutos = new ComboBox<>();

	// Criar bot�es da aba Produtos
	Button btnIncluirProdutos = new Button("Incluir");
	Button btnAlterarProdutos = new Button("Alterar");
	Button btnExcluirProdutos = new Button("Excluir");
	Button btnSalvarProdutos = new Button("Salvar");
	Button btnCancelarProdutos = new Button("Cancelar");
	Button btnPrimeiroProdutos = new Button("<<");
	Button btnAnteriorProdutos = new Button("<");
	Button btnProximoProdutos = new Button(">");
	Button btnUltimoProdutos = new Button(">>");
	//Button btnPesquisarProdutos = new Button("Pesquisar");

	//criar um ProdutoVO tempor�rio
	PedidoVO pedidoTemp = new PedidoVO();

	// Criar os campos de texto da aba Pedidos
	TextField txtIDPedidos = new TextField();
	ComboBox<String> cbxOperadorPedidos = new ComboBox<>();
	ComboBox<String> cbxTipoPedidoPedidos = new ComboBox<>();
	ComboBox<String> cbxClientePedidos = new ComboBox<>();	
	DatePicker dpkDataPedidos = new DatePicker();
	TextField txtValorTotalPedidos = new TextField();	
	ComboBox<String> cbxProdutoPedidos = new ComboBox<>();
	TextField txtQuantidadeProdutoPedidos = new TextField();	

	// Criar bot�es da aba Pedidos
	Button btnIncluirPedidos = new Button("Incluir");
	Button btnAlterarPedidos = new Button("Alterar");
	Button btnExcluirPedidos = new Button("Excluir");
	Button btnSalvarPedidos = new Button("Salvar");
	Button btnCancelarPedidos = new Button("Cancelar");
	Button btnPrimeiroPedidos = new Button("<<");
	Button btnAnteriorPedidos = new Button("<");
	Button btnProximoPedidos = new Button(">");
	Button btnUltimoPedidos = new Button(">>");
	//Button btnPesquisarPedidos = new Button("Pesquisar");
	//Button btnPesquisarProdutoPedidos = new Button("Pesquisar");
	Button btnAdicionarProdutoPedidos = new Button("Adicionar");
	Button btnExcluirProdutoPedidos = new Button("Excluir");

	// Criar tabela itens do pedido e parametrizar
	TableView<ItemPedidoVO> tabItensPedidoPedidos = new TableView<ItemPedidoVO>();

	public static void main(String[] args)
	{
		Application.launch(args);
	}

	public TelaPrincipal(UsuarioVO u) {
		this.uLogado = u;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage stage)
	{
		// Desabilitar bot�o de fechar abas;
		abaUsuarios.setClosable(false);
		abaClientes.setClosable(false);
		abaProdutos.setClosable(false);
		abaPedidos.setClosable(false);

		//Usuarios

		//Popular os combobox
		cbxFuncaoUsuarios.getItems().clear();
		ResultSet rs = FuncaoDAO.listaFuncoes();
		try {
			while(rs.next()){
				FuncaoVO f = FuncaoDAO.montaFuncaoVO(rs);
				cbxFuncaoUsuarios.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}
		cbxTipoUsuarioUsuarios.getItems().clear();
		rs = TipoUsuarioDAO.listaTiposUsuario();
		try {
			while(rs.next()){
				TipoUsuarioVO f = TipoUsuarioDAO.montaTipoUsuarioVO(rs);
				cbxTipoUsuarioUsuarios.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}

		// Definir largura dos bot�es
		double btnLarguraUsuarios = 100;
		btnIncluirUsuarios.setMinWidth(btnLarguraUsuarios);		
		btnAlterarUsuarios.setMinWidth(btnLarguraUsuarios);
		btnExcluirUsuarios.setMinWidth(btnLarguraUsuarios);
		btnSalvarUsuarios.setMinWidth(btnLarguraUsuarios);
		btnCancelarUsuarios.setMinWidth(btnLarguraUsuarios);
		btnPrimeiroUsuarios.setMinWidth(btnLarguraUsuarios);
		btnAnteriorUsuarios.setMinWidth(btnLarguraUsuarios);
		btnProximoUsuarios.setMinWidth(btnLarguraUsuarios);
		btnUltimoUsuarios.setMinWidth(btnLarguraUsuarios);
		//btnPesquisarUsuarios.setMinWidth(btnLarguraUsuarios);

		// Adicionar evento aos bot�es

		// Bot�o Primeiro Usu�rio
		btnPrimeiroUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					uTemp = UsuarioDAO.primeiro();
					preecheCamposUsuarios(uTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o �ltimo Usu�rio
		btnUltimoUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					uTemp = UsuarioDAO.ultimo();
					preecheCamposUsuarios(uTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o Usu�rio anterior
		btnAnteriorUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					uTemp = UsuarioDAO.anterior(txtIDUsuarios.getText());
					if (uTemp != null)
						preecheCamposUsuarios(uTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o pr�ximo Usu�rio
		btnProximoUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					uTemp = UsuarioDAO.proximo(txtIDUsuarios.getText());
					if (uTemp != null)
						preecheCamposUsuarios(uTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o incluir Usu�rio
		btnIncluirUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					limpaCamposUsuarios();
					modoEdicaoUsuarios();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o alterar Usu�rio
		btnAlterarUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoEdicaoUsuarios();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o excluir Usu�rio
		btnExcluirUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					if (uLogado.getId().equals(txtIDUsuarios.getText()))
					{
						Biblioteca.trataErro("N�o � poss�vel excluir o usu�rio atualmente logado");
						return;
					}
					UsuarioDAO.excluir(txtIDUsuarios.getText());
					uTemp = UsuarioDAO.primeiro();
					preecheCamposUsuarios(uTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o salvar Usu�rio
		btnSalvarUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					if(testaCamposUsuarios() == false)
						return;			
					uTemp.setId(txtIDUsuarios.getText());
					uTemp.setNome(txtNomeUsuarios.getText());
					uTemp.setTelefone(txtTelefoneUsuarios.getText().replace("(","").replace(")","").replace("-","").replace("_",""));
					uTemp.setEmail(txtEmailUsuarios.getText());
					uTemp.setFuncao(cbxFuncaoUsuarios.getValue().toString().substring(0, cbxFuncaoUsuarios.getValue().toString().indexOf(' ')));
					uTemp.setTipoUsuario(cbxTipoUsuarioUsuarios.getValue().toString().substring(0, cbxTipoUsuarioUsuarios.getValue().toString().indexOf(' ')));
					uTemp.setLogin(txtLoginUsuarios.getText());
					uTemp.setSenha(txtSenhaUsuarios.getText());
					if(txtIDUsuarios.getText().equals(""))
						UsuarioDAO.insere(uTemp);
					else
						UsuarioDAO.alterar(uTemp);
					modoNavegacaoUsuarios();
					uTemp = UsuarioDAO.ultimo();					
					preecheCamposUsuarios(uTemp);					
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});
		// Bot�o cancelar Usu�rio
		btnCancelarUsuarios.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoNavegacaoUsuarios();		
					uTemp = UsuarioDAO.primeiro();					
					preecheCamposUsuarios(uTemp);

				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	


		// Criar o gridpane
		GridPane rootUsuarios = new GridPane();	

		// Definir alinhamento
		rootUsuarios.setAlignment(Pos.TOP_CENTER);

		// Definir o espa�amento horizontal
		rootUsuarios.setHgap(10);

		// Definir o espa�amento vertical
		rootUsuarios.setVgap(30);

		// Mostrar o grid (Apenas para debugar)
		//rootUsuarios.setGridLinesVisible(true);

		// Adicionar labels e campos de texto ao gridpane			
		rootUsuarios.add(btnIncluirUsuarios, 0, 0);
		rootUsuarios.add(btnAlterarUsuarios, 1, 0);
		rootUsuarios.add(btnExcluirUsuarios, 2, 0);
		rootUsuarios.add(btnSalvarUsuarios, 3, 0);
		rootUsuarios.add(btnCancelarUsuarios, 4, 0);
		rootUsuarios.add(btnPrimeiroUsuarios, 5, 0);
		rootUsuarios.add(btnAnteriorUsuarios, 6, 0);
		rootUsuarios.add(btnProximoUsuarios, 7, 0);
		rootUsuarios.add(btnUltimoUsuarios, 8, 0);
		//rootUsuarios.add(btnPesquisarUsuarios, 9, 0);
		rootUsuarios.add(new Label("ID:"), 0, 1);
		rootUsuarios.add(txtIDUsuarios, 1, 1, 2, 1);
		rootUsuarios.add(new Label("Nome:"), 3, 1);
		txtNomeUsuarios.setMaxWidth(540);
		rootUsuarios.add(txtNomeUsuarios, 4, 1, 6, 1);
		rootUsuarios.add(new Label("Telefone:"), 0, 2);
		rootUsuarios.add(txtTelefoneUsuarios, 1, 2, 2, 1);
		txtEmailUsuarios.setMaxWidth(540);
		rootUsuarios.add(new Label("Email:"), 3, 2);
		rootUsuarios.add(txtEmailUsuarios, 4, 2, 6, 1);
		rootUsuarios.add(new Label("Fun��o:"), 0, 3);
		rootUsuarios.add(cbxFuncaoUsuarios, 1, 3, 2, 1);
		rootUsuarios.add(new Label("Tipo de Usu�rio:"), 3, 3);
		rootUsuarios.add(cbxTipoUsuarioUsuarios, 4, 3, 2, 1);
		rootUsuarios.add(new Label("Login:"), 0, 4);
		rootUsuarios.add(txtLoginUsuarios, 1, 4, 2, 1);
		rootUsuarios.add(new Label("Senha:"), 3, 4);		
		rootUsuarios.add(txtSenhaUsuarios, 4, 4, 2, 1);		

		// Definir tamanho do grid pane
		rootUsuarios.setMinSize(800, 400);

		/* 
		 * Set the padding of the GridPane
		 * Set the border-style of the GridPane
		 * Set the border-width of the GridPane
		 * Set the border-insets of the GridPane
		 * Set the border-radius of the GridPane
		 * Set the border-color of the GridPane
		 */
		rootUsuarios.setStyle("-fx-padding: 10;" +
				"-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-insets: 5;" +
				"-fx-border-radius: 5;" +
				"-fx-border-color: blue;");

		// Fim Usuarios

		// Clientes

		//Popular os combobox
		cbxCidadeClientes.getItems().clear();
		rs = CidadeDAO.listaCidades();
		try {
			while(rs.next()){
				CidadeVO f = CidadeDAO.montaCidadeVO(rs);
				cbxCidadeClientes.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}

		// Definir largura dos bot�es
		double btnLarguraClientes = 100;
		btnIncluirClientes.setMinWidth(btnLarguraClientes);		
		btnAlterarClientes.setMinWidth(btnLarguraClientes);
		btnExcluirClientes.setMinWidth(btnLarguraClientes);
		btnSalvarClientes.setMinWidth(btnLarguraClientes);
		btnCancelarClientes.setMinWidth(btnLarguraClientes);
		btnPrimeiroClientes.setMinWidth(btnLarguraClientes);
		btnAnteriorClientes.setMinWidth(btnLarguraClientes);
		btnProximoClientes.setMinWidth(btnLarguraClientes);
		btnUltimoClientes.setMinWidth(btnLarguraClientes);
		//btnPesquisarClientes.setMinWidth(btnLarguraClientes);

		// Adicionar evento aos bot�es

		// Bot�o Primeiro Cliente
		btnPrimeiroClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					cTemp = ClienteDAO.primeiro();
					preecheCamposClientes(cTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o �ltimo Cliente
		btnUltimoClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					cTemp = ClienteDAO.ultimo();
					preecheCamposClientes(cTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o Cliente anterior
		btnAnteriorClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					cTemp = ClienteDAO.anterior(txtIDClientes.getText());
					if (cTemp != null)
						preecheCamposClientes(cTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o pr�ximo Cliente
		btnProximoClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					cTemp = ClienteDAO.proximo(txtIDClientes.getText());
					if (cTemp != null)
						preecheCamposClientes(cTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o incluir Cliente
		btnIncluirClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					limpaCamposClientes();
					modoEdicaoClientes();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o alterar Cliente
		btnAlterarClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoEdicaoClientes();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o excluir Cliente
		btnExcluirClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					ClienteDAO.excluir(txtIDClientes.getText());
					cTemp = ClienteDAO.primeiro();
					preecheCamposClientes(cTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o salvar Cliente
		btnSalvarClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					if(testaCamposClientes() == false)
						return;			
					cTemp.setId(txtIDClientes.getText());
					cTemp.setNome(txtNomeClientes.getText());
					cTemp.setTelefone(txtTelefoneClientes.getText().replace("(","").replace(")","").replace("-","").replace("_",""));
					cTemp.setEmail(txtEmailClientes.getText());
					cTemp.setEndereco(txtEnderecoClientes.getText());
					cTemp.setNumero(txtNumeroClientes.getText());
					cTemp.setComplemento(txtComplementoClientes.getText());
					cTemp.setBairro(txtBairroClientes.getText());
					cTemp.setCidade_ID(cbxCidadeClientes.getValue().toString().substring(0, cbxCidadeClientes.getValue().toString().indexOf(' ')));					
					cTemp.setCep(txtCepClientes.getText().replace("-","").replace("_",""));
					if(txtIDClientes.getText().equals(""))
						ClienteDAO.insere(cTemp);
					else
						ClienteDAO.alterar(cTemp);
					modoNavegacaoClientes();
					cTemp = ClienteDAO.ultimo();					
					preecheCamposClientes(cTemp);					
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});
		// Bot�o cancelar Cliente
		btnCancelarClientes.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoNavegacaoClientes();		
					cTemp = ClienteDAO.primeiro();					
					preecheCamposClientes(cTemp);

				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Criar o gridpane
		GridPane rootClientes = new GridPane();		

		// Definir alinhamento
		rootClientes.setAlignment(Pos.TOP_CENTER);;

		// Definir o espa�amento horizontal
		rootClientes.setHgap(10);

		// Definir o espa�amento vertical
		rootClientes.setVgap(30);

		// Mostrar o grid (Apenas para debugar)
		//rootClientes.setGridLinesVisible(true);

		// Adicionar labels e campos de texto ao gridpane				
		rootClientes.add(btnIncluirClientes, 0, 0);
		rootClientes.add(btnAlterarClientes, 1, 0);
		rootClientes.add(btnExcluirClientes, 2, 0);
		rootClientes.add(btnSalvarClientes, 3, 0);
		rootClientes.add(btnCancelarClientes, 4, 0);
		rootClientes.add(btnPrimeiroClientes, 5, 0);
		rootClientes.add(btnAnteriorClientes, 6, 0);
		rootClientes.add(btnProximoClientes, 7, 0);
		rootClientes.add(btnUltimoClientes, 8, 0);
		//rootClientes.add(btnPesquisarClientes, 9, 0);
		rootClientes.add(new Label("ID:"), 0, 1);
		rootClientes.add(txtIDClientes, 1, 1, 2, 1);
		rootClientes.add(new Label("Nome:"), 3, 1);
		txtNomeClientes.setMaxWidth(540);
		rootClientes.add(txtNomeClientes, 4, 1, 6, 1);
		rootClientes.add(new Label("Telefone:"), 0, 2);
		rootClientes.add(txtTelefoneClientes, 1, 2, 2, 1);
		txtEmailClientes.setMaxWidth(540);
		rootClientes.add(new Label("Email:"), 3, 2);
		rootClientes.add(txtEmailClientes, 4, 2, 6, 1);
		rootClientes.add(new Label("Endere�o:"), 0, 3);
		rootClientes.add(txtEnderecoClientes, 1, 3, 4, 1);
		rootClientes.add(new Label("N�mero:"), 5, 3);
		txtNumeroClientes.setMaxWidth(100);
		rootClientes.add(txtNumeroClientes, 6, 3, 4, 1);
		rootClientes.add(new Label("Complemento:"), 0, 4);
		rootClientes.add(txtComplementoClientes, 1, 4, 4, 1);		
		rootClientes.add(new Label("Bairro:"), 5, 4);
		txtBairroClientes.setMaxWidth(320);
		rootClientes.add(txtBairroClientes, 6, 4, 4, 1);		
		rootClientes.add(new Label("Cidade:"), 0, 5);
		rootClientes.add(cbxCidadeClientes, 1, 5, 2, 1);		
		rootClientes.add(new Label("CEP:"), 5, 5);
		txtCepClientes.setMaxWidth(100);
		rootClientes.add(txtCepClientes, 6, 5, 4, 1);

		// Definir tamanho do grid pane
		rootClientes.setMinSize(800, 400);

		/* 
		 * Set the padding of the GridPane
		 * Set the border-style of the GridPane
		 * Set the border-width of the GridPane
		 * Set the border-insets of the GridPane
		 * Set the border-radius of the GridPane
		 * Set the border-color of the GridPane
		 */
		rootClientes.setStyle("-fx-padding: 10;" +
				"-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-insets: 5;" +
				"-fx-border-radius: 5;" +
				"-fx-border-color: yellow;");

		// Fim Clientes

		// Produtos

		//Popular os combobox
		cbxCategoriaProdutos.getItems().clear();
		rs = CategoriaDAO.listaCategorias();
		try {
			while(rs.next()){
				CategoriaVO f = CategoriaDAO.montaCategoriaVO(rs);
				cbxCategoriaProdutos.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}
		cbxInventarioProdutos.getItems().clear();
		cbxInventarioProdutos.getItems().add("Sim");
		cbxInventarioProdutos.getItems().add("N�o");

		// Definir largura dos bot�es
		double btnLarguraProdutos = 100;
		btnIncluirProdutos.setMinWidth(btnLarguraProdutos);		
		btnAlterarProdutos.setMinWidth(btnLarguraProdutos);
		btnExcluirProdutos.setMinWidth(btnLarguraProdutos);
		btnSalvarProdutos.setMinWidth(btnLarguraProdutos);
		btnCancelarProdutos.setMinWidth(btnLarguraProdutos);
		btnPrimeiroProdutos.setMinWidth(btnLarguraProdutos);
		btnAnteriorProdutos.setMinWidth(btnLarguraProdutos);
		btnProximoProdutos.setMinWidth(btnLarguraProdutos);
		btnUltimoProdutos.setMinWidth(btnLarguraProdutos);
		//btnPesquisarProdutos.setMinWidth(btnLarguraProdutos);

		// Adicionar evento aos bot�es

		// Bot�o Primeiro Produto
		btnPrimeiroProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pTemp = ProdutoDAO.primeiro();
					preecheCamposProdutos(pTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o �ltimo Produto
		btnUltimoProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pTemp = ProdutoDAO.ultimo();
					preecheCamposProdutos(pTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o Produto anterior
		btnAnteriorProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pTemp = ProdutoDAO.anterior(txtIDProdutos.getText());
					if (pTemp != null)
						preecheCamposProdutos(pTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o pr�ximo Produto
		btnProximoProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pTemp = ProdutoDAO.proximo(txtIDProdutos.getText());
					if (pTemp != null)
						preecheCamposProdutos(pTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o incluir Produto
		btnIncluirProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					limpaCamposProdutos();
					modoEdicaoProdutos();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o alterar Produto
		btnAlterarProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoEdicaoProdutos();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o excluir Produto
		btnExcluirProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					ProdutoDAO.excluir(txtIDProdutos.getText());
					pTemp = ProdutoDAO.primeiro();
					preecheCamposProdutos(pTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o salvar Produto
		btnSalvarProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					if(testaCamposProdutos() == false)
						return;			
					pTemp.setId(txtIDProdutos.getText());
					pTemp.setCategoriaID(cbxCategoriaProdutos.getValue().toString().substring(0, cbxCategoriaProdutos.getValue().toString().indexOf(' ')));
					pTemp.setDescricao(txtDescricaoProdutos.getText());							
					pTemp.setValor(Double.parseDouble(txtValorProdutos.getText().replace(",", ".")));
					pTemp.setCaminhoFoto("");
					pTemp.setQuantidadeEstoque(Integer.parseInt(txtQuantidadeProdutos.getText().replace(",", ".")));
					if (cbxInventarioProdutos.getValue().toString().equals("Sim"))
						pTemp.setInventario(true);
					else
						pTemp.setInventario(false);
					if(txtIDProdutos.getText().equals(""))
						ProdutoDAO.insere(pTemp);
					else
						ProdutoDAO.alterar(pTemp);
					modoNavegacaoProdutos();
					pTemp = ProdutoDAO.ultimo();					
					preecheCamposProdutos(pTemp);					
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});

		// Bot�o cancelar Produto
		btnCancelarProdutos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoNavegacaoProdutos();		
					pTemp = ProdutoDAO.primeiro();					
					preecheCamposProdutos(pTemp);

				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		//Adicionar evento aos combobox

		//Combobox invent�rio Produtos

		cbxInventarioProdutos.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override public void handle(ActionEvent e)
			{				
				if (edicaoProdutos == true) {
					if (cbxInventarioProdutos.getValue().toString().equals("Sim"))
						txtQuantidadeProdutos.setEditable(true);
					else
					{
						txtQuantidadeProdutos.setEditable(false);
						txtQuantidadeProdutos.setText("0");
					}
				}
			}
		});


		// Criar o gridpane
		GridPane rootProdutos = new GridPane();		

		// Definir alinhamento
		rootProdutos.setAlignment(Pos.TOP_CENTER);;

		// Definir o espa�amento horizontal
		rootProdutos.setHgap(10);

		// Definir o espa�amento vertical
		rootProdutos.setVgap(30);

		// Mostrar o grid (Apenas para debugar)
		//rootProdutos.setGridLinesVisible(true);

		// Adicionar labels e campos de texto ao gridpane				
		rootProdutos.add(btnIncluirProdutos, 0, 0);
		rootProdutos.add(btnAlterarProdutos, 1, 0);
		rootProdutos.add(btnExcluirProdutos, 2, 0);
		rootProdutos.add(btnSalvarProdutos, 3, 0);
		rootProdutos.add(btnCancelarProdutos, 4, 0);
		rootProdutos.add(btnPrimeiroProdutos, 5, 0);
		rootProdutos.add(btnAnteriorProdutos, 6, 0);
		rootProdutos.add(btnProximoProdutos, 7, 0);
		rootProdutos.add(btnUltimoProdutos, 8, 0);
		//rootProdutos.add(btnPesquisarProdutos, 9, 0);
		rootProdutos.add(new Label("ID:"), 0, 1);
		rootProdutos.add(txtIDProdutos, 1, 1, 2, 1);
		rootProdutos.add(new Label("Descri��o:"), 3, 1);
		txtDescricaoProdutos.setMaxWidth(540);
		rootProdutos.add(txtDescricaoProdutos, 4, 1, 5, 1);
		rootProdutos.add(new Label("Categoria:"), 0, 2);
		rootProdutos.add(cbxCategoriaProdutos, 1, 2, 2, 1);
		rootProdutos.add(new Label("Valor:"), 3, 2);
		txtValorProdutos.setMaxWidth(100);
		rootProdutos.add(txtValorProdutos, 4, 2, 1, 1);
		rootProdutos.add(new Label("Inventario:"), 5, 2);
		rootProdutos.add(cbxInventarioProdutos, 6, 2, 2, 1);
		rootProdutos.add(new Label("Quantidade:"), 7, 2);
		txtQuantidadeProdutos.setMaxWidth(100);
		rootProdutos.add(txtQuantidadeProdutos, 8, 2, 1, 1);				

		// Definir tamanho do grid pane
		rootProdutos.setMinSize(800, 400);		

		/* 
		 * Set the padding of the GridPane
		 * Set the border-style of the GridPane
		 * Set the border-width of the GridPane
		 * Set the border-insets of the GridPane
		 * Set the border-radius of the GridPane
		 * Set the border-color of the GridPane
		 */
		rootProdutos.setStyle("-fx-padding: 10;" +
				"-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-insets: 5;" +
				"-fx-border-radius: 5;" +
				"-fx-border-color: red;");

		// Fim Produtos

		// Pedidos

		// Parametrizar tabela itens do pedido

		tabItensPedidoPedidos.setEditable(true);

		TableColumn colProdutoPedidos = new TableColumn("Produto ID");
		colProdutoPedidos.setCellValueFactory(new PropertyValueFactory<ItemPedidoVO, String>("produtoID"));
		colProdutoPedidos.setMinWidth(150);        
		TableColumn colDescricaoPedidos = new TableColumn("Descri��o");
		colDescricaoPedidos.setCellValueFactory(new PropertyValueFactory<ItemPedidoVO, String>("descricao"));
		colDescricaoPedidos.setMinWidth(390);
		TableColumn colQuantidadePedidos = new TableColumn("Quantidade");
		colQuantidadePedidos.setCellValueFactory(new PropertyValueFactory<ItemPedidoVO, Integer>("quantidadeFormatado"));
		colQuantidadePedidos.setMinWidth(150);	
		TableColumn colValorUnitarioPedidos = new TableColumn("Valor Unit�rio");
		colValorUnitarioPedidos.setCellValueFactory(new PropertyValueFactory<ItemPedidoVO, Double>("valorUnitarioFormatado"));
		colValorUnitarioPedidos.setMinWidth(150);
		TableColumn colValorTotalPedidos = new TableColumn("Valor Total");
		colValorTotalPedidos.setCellValueFactory(new PropertyValueFactory<ItemPedidoVO, Double>("valorTotal"));
		colValorTotalPedidos.setMinWidth(150);
		tabItensPedidoPedidos.getColumns().addAll(colProdutoPedidos, colDescricaoPedidos, colQuantidadePedidos,
				colValorUnitarioPedidos, colValorTotalPedidos);

		//Popular os combobox
		cbxOperadorPedidos.getItems().clear();
		rs = UsuarioDAO.listaUsuarios();
		try {
			while(rs.next()){
				UsuarioVO f = UsuarioDAO.montaUsuarioVO(rs);
				cbxOperadorPedidos.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}
		cbxTipoPedidoPedidos.getItems().clear();
		rs = TipoPedidoDAO.listaTiposPedido();
		try {
			while(rs.next()){
				TipoPedidoVO f = TipoPedidoDAO.montaTipoPedidoVO(rs);
				cbxTipoPedidoPedidos.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}
		cbxClientePedidos.getItems().clear();
		rs = ClienteDAO.listaClientes();
		try {
			while(rs.next()){
				ClienteVO f = ClienteDAO.montaClienteVO(rs);
				cbxClientePedidos.getItems().add(f.getId() + " - " + f.getNome());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}
		cbxProdutoPedidos.getItems().clear();
		rs = ProdutoDAO.listaProdutos();
		try {
			while(rs.next()){
				ProdutoVO f = ProdutoDAO.montaProdutoVO(rs);
				cbxProdutoPedidos.getItems().add(f.getId() + " - " + f.getDescricao());				
			}
		} catch (SQLException ex) {
			Biblioteca.trataErro(ex);	
		}

		// Definir largura dos bot�es
		double btnLarguraPedidos = 100;
		btnIncluirPedidos.setMinWidth(btnLarguraPedidos);		
		btnAlterarPedidos.setMinWidth(btnLarguraPedidos);
		btnExcluirPedidos.setMinWidth(btnLarguraPedidos);
		btnSalvarPedidos.setMinWidth(btnLarguraPedidos);
		btnCancelarPedidos.setMinWidth(btnLarguraPedidos);
		btnPrimeiroPedidos.setMinWidth(btnLarguraPedidos);
		btnAnteriorPedidos.setMinWidth(btnLarguraPedidos);
		btnProximoPedidos.setMinWidth(btnLarguraPedidos);
		btnUltimoPedidos.setMinWidth(btnLarguraPedidos);
		//btnPesquisarPedidos.setMinWidth(btnLarguraPedidos);
		//btnPesquisarProdutoPedidos.setMinWidth(btnLarguraPedidos);
		btnAdicionarProdutoPedidos.setMinWidth(btnLarguraPedidos);
		btnExcluirProdutoPedidos.setMinWidth(btnLarguraPedidos);

		// Adicionar evento aos bot�es

		// Bot�o Primeiro Pedido
		btnPrimeiroPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pedidoTemp = PedidoDAO.primeiro();
					preecheCamposPedidos(pedidoTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o �ltimo Pedido
		btnUltimoPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pedidoTemp = PedidoDAO.ultimo();
					preecheCamposPedidos(pedidoTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o Pedido anterior
		btnAnteriorPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pedidoTemp = PedidoDAO.anterior(txtIDPedidos.getText());
					if (pedidoTemp != null)
						preecheCamposPedidos(pedidoTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o pr�ximo Pedido
		btnProximoPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					pedidoTemp = PedidoDAO.proximo(txtIDPedidos.getText());
					if (pedidoTemp != null)
						preecheCamposPedidos(pedidoTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});		

		// Bot�o incluir Pedido
		btnIncluirPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					modoEdicaoPedidos();
					limpaCamposPedidos();					
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o alterar Pedido
		btnAlterarPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoEdicaoPedidos();
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o excluir Pedido
		btnExcluirPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {
					PedidoDAO.excluir(txtIDPedidos.getText());
					pedidoTemp = PedidoDAO.primeiro();
					preecheCamposPedidos(pedidoTemp);
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o salvar Pedido
		btnSalvarPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					if(testaCamposPedidos() == false)
						return;			
					pedidoTemp.setId(txtIDPedidos.getText());
					pedidoTemp.setUsuarioID(cbxOperadorPedidos.getValue().toString().substring(0, cbxOperadorPedidos.getValue().toString().indexOf(' ')));												
					pedidoTemp.setTipoPedidoID(cbxTipoPedidoPedidos.getValue().toString().substring(0, cbxTipoPedidoPedidos.getValue().toString().indexOf(' ')));
					if (cbxClientePedidos.getValue().toString().equals(""))
						pedidoTemp.setClienteID("");
					else
						pedidoTemp.setClienteID(cbxClientePedidos.getValue().toString().substring(0, cbxClientePedidos.getValue().toString().indexOf(' ')));
					pedidoTemp.setValorTotal(Double.parseDouble(txtValorTotalPedidos.getText().replace(",", ".")));
					LocalDate localDate = dpkDataPedidos.getValue();
					Instant instant = Instant.from(localDate.atStartOfDay(ZoneId.systemDefault()));
					pedidoTemp.setData(Date.from(instant));
					pedidoTemp.setItensPedido(tabItensPedidoPedidos.getItems());
					if(txtIDPedidos.getText().equals(""))
						PedidoDAO.insere(pedidoTemp);
					else
						PedidoDAO.alterar(pedidoTemp);
					modoNavegacaoPedidos();
					limpaCamposPedidos();
					pedidoTemp = PedidoDAO.ultimo();					
					preecheCamposPedidos(pedidoTemp);					
				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});

		// Bot�o cancelar Pedido
		btnCancelarPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				try {			
					modoNavegacaoPedidos();		
					limpaCamposPedidos();
					pedidoTemp = PedidoDAO.primeiro();					
					preecheCamposPedidos(pedidoTemp);

				}
				catch(Exception ex) {
					Biblioteca.trataErro(ex);									
				}
			}
		});	

		// Bot�o adicionar produto
		btnAdicionarProdutoPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{			
				try {	
					if(testaCamposProdutoPedidos() == false)
						return;		
					ItemPedidoVO i = new ItemPedidoVO();
					ProdutoVO j = new ProdutoVO();
					i.setProdutoID(cbxProdutoPedidos.getValue().toString().substring(0, cbxProdutoPedidos.getValue().toString().indexOf(' ')));					
					j = ProdutoDAO.consultaId(i.getProdutoID());
					i.setQuantidade(Double.parseDouble(txtQuantidadeProdutoPedidos.getText().replace(",", ".")));
					i.setDescricao(j.getDescricao());				
					i.setValorUnitario(j.getValor());					
					pedidoTemp.setItensPedido(tabItensPedidoPedidos.getItems());
					String busca = i.getProdutoID();
					for(ItemPedidoVO v : tabItensPedidoPedidos.getItems()){
						if(v.getProdutoID() != null && v.getProdutoID().contains(busca)) {							
							v.setQuantidade(v.getQuantidade() + i.getQuantidade());	
							tabItensPedidoPedidos.refresh();
							txtValorTotalPedidos.setText(String.format("%.2f",calculaValorTotalPedido()));	
							return;
						}						
					}	
					tabItensPedidoPedidos.getItems().add(i);
					txtValorTotalPedidos.setText(String.format("%.2f",calculaValorTotalPedido()));	
				}
				catch(Exception ex){
					Biblioteca.trataErro(ex);	
				}
			}
		});	

		// Bot�o excluir produto
		btnExcluirProdutoPedidos.setOnAction(new EventHandler<ActionEvent>() 
		{
			@Override public void handle(ActionEvent e) 
			{
				ItemPedidoVO t = tabItensPedidoPedidos.getSelectionModel().getSelectedItem();
				tabItensPedidoPedidos.getItems().remove(t);
				txtValorTotalPedidos.setText(String.format("%.2f",calculaValorTotalPedido()));	
			}
		});	

		//Adicionar evento aos combobox

		//Combobox tipo de pedido Produtos				

		cbxTipoPedidoPedidos.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override public void handle(ActionEvent e)
			{
				if (cbxTipoPedidoPedidos.getValue().toString().substring(0, 
						cbxTipoPedidoPedidos.getValue().toString().indexOf(' ')).equals("2") && edicaoPedidos == true)
					cbxClientePedidos.setDisable(false);
				else
				{
					cbxClientePedidos.setDisable(true);
					cbxClientePedidos.getSelectionModel().select("");
				}
			}
		});

		// Criar o gridpane
		GridPane rootPedidos = new GridPane();		

		// Definir alinhamento
		rootPedidos.setAlignment(Pos.TOP_CENTER);;

		// Definir o espa�amento horizontal
		rootPedidos.setHgap(10);

		// Definir o espa�amento vertical
		rootPedidos.setVgap(30);

		// Mostrar o grid (Apenas para debugar)
		//rootPedidos.setGridLinesVisible(true);

		// Adicionar labels e campos de texto ao gridpane				
		rootPedidos.add(btnIncluirPedidos, 0, 0);
		rootPedidos.add(btnAlterarPedidos, 1, 0);
		rootPedidos.add(btnExcluirPedidos, 2, 0);
		rootPedidos.add(btnSalvarPedidos, 3, 0);
		rootPedidos.add(btnCancelarPedidos, 4, 0);
		rootPedidos.add(btnPrimeiroPedidos, 5, 0);
		rootPedidos.add(btnAnteriorPedidos, 6, 0);
		rootPedidos.add(btnProximoPedidos, 7, 0);
		rootPedidos.add(btnUltimoPedidos, 8, 0);
		//rootPedidos.add(btnPesquisarPedidos, 9, 0);
		rootPedidos.add(new Label("ID:"), 0, 1);
		rootPedidos.add(txtIDPedidos, 1, 1, 2, 1);
		rootPedidos.add(new Label("Operador:"), 3, 1);
		rootPedidos.add(cbxOperadorPedidos, 4, 1, 3, 1);
		rootPedidos.add(new Label("Tipo de Pedido:"), 0, 2);
		rootPedidos.add(cbxTipoPedidoPedidos, 1, 2, 2, 1);
		rootPedidos.add(new Label("Cliente:"), 3, 2);
		rootPedidos.add(cbxClientePedidos, 4, 2, 2, 1);
		rootPedidos.add(new Label("Data:"), 0, 3);
		rootPedidos.add(dpkDataPedidos, 1, 3, 4, 1);
		rootPedidos.add(new Label("Valor Total:"), 3, 3);
		txtValorTotalPedidos.setMaxWidth(100);
		rootPedidos.add(txtValorTotalPedidos, 4, 3, 4, 1);
		rootPedidos.add(new Label("Produto:"), 0, 4);
		rootPedidos.add(cbxProdutoPedidos, 1, 4, 4, 1);
		rootPedidos.add(new Label("Quantidade:"), 3, 4);
		txtQuantidadeProdutoPedidos.setMaxWidth(100);
		rootPedidos.add(txtQuantidadeProdutoPedidos, 4, 4, 1, 1);
		//rootPedidos.add(btnPesquisarProdutoPedidos, 6, 4);
		rootPedidos.add(btnAdicionarProdutoPedidos, 5, 4);
		rootPedidos.add(btnExcluirProdutoPedidos, 6, 4);
		rootPedidos.add(tabItensPedidoPedidos, 0, 5, 10, 1);


		// Definir tamanho do grid pane
		rootPedidos.setMinSize(800, 400);

		/* 
		 * Set the padding of the GridPane
		 * Set the border-style of the GridPane
		 * Set the border-width of the GridPane
		 * Set the border-insets of the GridPane
		 * Set the border-radius of the GridPane
		 * Set the border-color of the GridPane
		 */
		rootPedidos.setStyle("-fx-padding: 10;" +
				"-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-insets: 5;" +
				"-fx-border-radius: 5;" +
				"-fx-border-color: green;");

		// Fim Pedidos

		// Adiciona o conteudo a aba Usu�rios
		abaUsuarios.setContent(rootUsuarios);

		// Adiciona o conteudo a aba Clientes
		abaClientes.setContent(rootClientes);

		// Adiciona o conteudo a aba Produtos
		abaProdutos.setContent(rootProdutos);

		// Adiciona o conteudo a aba Pedidos
		abaPedidos.setContent(rootPedidos);

		// Adicionando todas as abas de vez
		if(uLogado.getTipoUsuario().equals("2"))
		{
			painelAbas.getTabs().addAll(abaUsuarios, abaClientes, abaProdutos, abaPedidos);
		}
		else
		{
			painelAbas.getTabs().addAll(abaPedidos);
		}
		// Criar a scene
		Scene scene = new Scene(painelAbas, 1040, 600);
		// Adicionar scene ao stage
		stage.setScene(scene);
		// Definir t�tulo
		stage.setTitle("Padoca da Camila - Bem vindo! =)");
		//Bloquear altera��es no tamanho da janela
		stage.setResizable(false);
		//Carregar tela de usuarios com o primeiro usu�rio do banco
		try {
			uTemp = UsuarioDAO.primeiro();
		}
		catch(Exception ex) {
			Biblioteca.trataErro(ex);									
		}
		preecheCamposUsuarios(uTemp);
		modoNavegacaoUsuarios();
		//Carregar tela de clientes com o primeiro cliente do banco
		try {
			cTemp = ClienteDAO.primeiro();
		}
		catch(Exception ex) {
			Biblioteca.trataErro(ex);									
		}
		preecheCamposClientes(cTemp);
		modoNavegacaoClientes();
		//Carregar tela de produtos com o primeiro cliente do banco
		try {
			pTemp = ProdutoDAO.primeiro();
		}
		catch(Exception ex) {
			Biblioteca.trataErro(ex);									
		}
		preecheCamposProdutos(pTemp);
		modoNavegacaoProdutos();
		//Carregar tela de pedidos com o primeiro pedido do banco
		try {
			pedidoTemp = PedidoDAO.primeiro();
		}
		catch(Exception ex) {
			Biblioteca.trataErro(ex);									
		}
		preecheCamposPedidos(pedidoTemp);
		modoNavegacaoPedidos();
		// Mostrar tela
		stage.show();		

	}

	//Preenche os campos da aba usu�rios com um objeto UsuarioVO
	private void preecheCamposUsuarios(UsuarioVO u){    
		if(!u.getId().equals(null)) {
			txtIDUsuarios.setText(u.getId());
			txtNomeUsuarios.setText(u.getNome());			
			txtTelefoneUsuarios.setPlainText(u.getTelefone());
			txtEmailUsuarios.setText(u.getEmail());
			String funcaoUsuarios = u.getFuncao();
			ObservableList<String> items = cbxFuncaoUsuarios.getItems();
			for(String item : items){
				if (item.toString().substring(0, item.toString().indexOf(' ')).equals(funcaoUsuarios))
				{
					cbxFuncaoUsuarios.getSelectionModel().select(item.toString());
				}
			}	
			String tipoUsuarioUsuarios = u.getTipoUsuario();
			items = cbxTipoUsuarioUsuarios.getItems();
			for(String item : items){
				if (item.toString().substring(0, item.toString().indexOf(' ')).equals(tipoUsuarioUsuarios))
				{
					cbxTipoUsuarioUsuarios.getSelectionModel().select(item.toString());
				}
			}		
			txtLoginUsuarios.setText(u.getLogin());
			txtSenhaUsuarios.setText(u.getSenha());    
		}
	}

	//Limpa campos da aba usu�rios
	private void limpaCamposUsuarios() {
		txtIDUsuarios.setText("");
		txtNomeUsuarios.setText("");
		txtTelefoneUsuarios.setPlainText("");
		txtEmailUsuarios.setText("");
		cbxFuncaoUsuarios.getSelectionModel().select("");
		cbxTipoUsuarioUsuarios.getSelectionModel().select("");
		txtLoginUsuarios.setText("");
		txtSenhaUsuarios.setText(""); 
	}

	//Muda a aba usu�rios para navega��o
	private void modoNavegacaoUsuarios() {
		txtIDUsuarios.setEditable(false);
		txtNomeUsuarios.setEditable(false);
		txtTelefoneUsuarios.setEditable(false);
		txtEmailUsuarios.setEditable(false);
		cbxFuncaoUsuarios.setDisable(true);
		cbxTipoUsuarioUsuarios.setDisable(true);
		txtLoginUsuarios.setEditable(false);
		txtSenhaUsuarios.setEditable(false);
		btnIncluirUsuarios.setDisable(false);		
		btnAlterarUsuarios.setDisable(false);
		btnExcluirUsuarios.setDisable(false);
		btnSalvarUsuarios.setDisable(true);
		btnCancelarUsuarios.setDisable(true);
		btnPrimeiroUsuarios.setDisable(false);
		btnAnteriorUsuarios.setDisable(false);
		btnProximoUsuarios.setDisable(false);
		btnUltimoUsuarios.setDisable(false);
		//btnPesquisarUsuarios.setDisable(false);
		navegacaoUsuarios = true;
		edicaoUsuarios = false;
		abaUsuarios.setDisable(false);
		abaClientes.setDisable(false);
		abaProdutos.setDisable(false);
		abaPedidos.setDisable(false);
	}

	//Muda a aba usu�rios para edi��o
	private void modoEdicaoUsuarios() {
		txtIDUsuarios.setEditable(false);
		txtNomeUsuarios.setEditable(true);
		txtTelefoneUsuarios.setEditable(true);
		txtEmailUsuarios.setEditable(true);
		cbxFuncaoUsuarios.setDisable(false);
		cbxTipoUsuarioUsuarios.setDisable(false);
		txtLoginUsuarios.setEditable(true);
		txtSenhaUsuarios.setEditable(true);
		btnIncluirUsuarios.setDisable(true);		
		btnAlterarUsuarios.setDisable(true);
		btnExcluirUsuarios.setDisable(true);
		btnSalvarUsuarios.setDisable(false);
		btnCancelarUsuarios.setDisable(false);
		btnPrimeiroUsuarios.setDisable(true);
		btnAnteriorUsuarios.setDisable(true);
		btnProximoUsuarios.setDisable(true);
		btnUltimoUsuarios.setDisable(true);
		//btnPesquisarUsuarios.setDisable(true);
		navegacaoUsuarios = false;
		edicaoUsuarios = true;
		abaUsuarios.setDisable(false);
		abaClientes.setDisable(true);
		abaProdutos.setDisable(true);
		abaPedidos.setDisable(true);
	}

	//Verificar campos da aba usu�rios
	private boolean testaCamposUsuarios() {
		if (txtNomeUsuarios.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo nome");
			return false;
		}
		if (txtTelefoneUsuarios.getText().replace("(","").replace(")","").replace("-","").replace("_","").equals(""))
		{
			Biblioteca.trataErro("Preencha o campo telefone");
			return false;
		}
		if (txtTelefoneUsuarios.getText().replace("(","").replace(")","").replace("-","").replace("_","").length() < 10)
		{
			Biblioteca.trataErro("Preencha o campo telefone com ao menos 10 digitos");
			return false;
		}
		if (txtEmailUsuarios.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo email");
			return false;
		}
		if (cbxFuncaoUsuarios.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo fun��o");
			return false;
		}
		if (cbxTipoUsuarioUsuarios.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo tipo de usu�rio");
			return false;
		}
		if (txtLoginUsuarios.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo login");
			return false;
		}
		if (txtSenhaUsuarios.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo senha");
			return false;
		}
		return true;
	}

	//Preenche os campos da aba Clientes com um objeto ClienteVO
	private void preecheCamposClientes(ClienteVO u){    
		if(!u.getId().equals(null)) {
			txtIDClientes.setText(u.getId());
			txtNomeClientes.setText(u.getNome());				
			txtTelefoneClientes.setPlainText(u.getTelefone());
			txtEmailClientes.setText(u.getEmail());
			txtEnderecoClientes.setText(u.getEndereco());
			txtNumeroClientes.setText(u.getNumero());				
			txtComplementoClientes.setText(u.getComplemento());
			txtBairroClientes.setText(u.getBairro());
			String cidadeClientes = u.getCidade_ID();
			ObservableList<String> items = cbxCidadeClientes.getItems();
			for(String item : items){
				if (item.toString().substring(0, item.toString().indexOf(' ')).equals(cidadeClientes))
				{
					cbxCidadeClientes.getSelectionModel().select(item.toString());
				}
			}					
			txtCepClientes.setPlainText(u.getCep());

		}
	}

	//Limpa campos da aba Clientes
	private void limpaCamposClientes() {
		txtIDClientes.setText("");
		txtNomeClientes.setText("");
		txtTelefoneClientes.setPlainText("");
		txtEmailClientes.setText("");
		txtEnderecoClientes.setText("");
		txtNumeroClientes.setText("");
		txtComplementoClientes.setText("");
		txtBairroClientes.setText("");
		cbxCidadeClientes.getSelectionModel().select("");		
		txtCepClientes.setPlainText("");
	}

	//Muda a aba Clientes para navega��o
	private void modoNavegacaoClientes() {
		txtIDClientes.setEditable(false);
		txtNomeClientes.setEditable(false);
		txtTelefoneClientes.setEditable(false);
		txtEmailClientes.setEditable(false);
		txtEnderecoClientes.setEditable(false);
		txtNumeroClientes.setEditable(false);
		txtComplementoClientes.setEditable(false);
		txtBairroClientes.setEditable(false);
		cbxCidadeClientes.setDisable(true);		
		txtCepClientes.setEditable(false);
		btnIncluirClientes.setDisable(false);		
		btnAlterarClientes.setDisable(false);
		btnExcluirClientes.setDisable(false);
		btnSalvarClientes.setDisable(true);
		btnCancelarClientes.setDisable(true);
		btnPrimeiroClientes.setDisable(false);
		btnAnteriorClientes.setDisable(false);
		btnProximoClientes.setDisable(false);
		btnUltimoClientes.setDisable(false);
		//btnPesquisarClientes.setDisable(false);
		navegacaoClientes = true;
		edicaoClientes = false;
		abaUsuarios.setDisable(false);
		abaClientes.setDisable(false);
		abaProdutos.setDisable(false);
		abaPedidos.setDisable(false);
	}

	//Muda a aba Clientes para edi��o
	private void modoEdicaoClientes() {
		txtIDClientes.setEditable(false);
		txtNomeClientes.setEditable(true);
		txtTelefoneClientes.setEditable(true);
		txtEmailClientes.setEditable(true);
		txtEnderecoClientes.setEditable(true);
		txtNumeroClientes.setEditable(true);
		txtComplementoClientes.setEditable(true);
		txtBairroClientes.setEditable(true);
		cbxCidadeClientes.setDisable(false);		
		txtCepClientes.setEditable(true);
		btnIncluirClientes.setDisable(true);		
		btnAlterarClientes.setDisable(true);
		btnExcluirClientes.setDisable(true);
		btnSalvarClientes.setDisable(false);
		btnCancelarClientes.setDisable(false);
		btnPrimeiroClientes.setDisable(true);
		btnAnteriorClientes.setDisable(true);
		btnProximoClientes.setDisable(true);
		btnUltimoClientes.setDisable(true);
		//btnPesquisarClientes.setDisable(true);
		navegacaoClientes = false;
		edicaoClientes = true;
		abaUsuarios.setDisable(true);
		abaClientes.setDisable(false);
		abaProdutos.setDisable(true);
		abaPedidos.setDisable(true);
	}

	//Verificar campos da aba Clientes
	private boolean testaCamposClientes() {
		if (txtNomeClientes.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo nome");
			return false;
		}
		if (txtTelefoneClientes.getText().replace("(","").replace(")","").replace("-","").replace("_","").equals(""))
		{
			Biblioteca.trataErro("Preencha o campo telefone");
			return false;
		}
		if (txtTelefoneClientes.getText().replace("(","").replace(")","").replace("-","").replace("_","").length() < 10)
		{
			Biblioteca.trataErro("Preencha o campo telefone com ao menos 10 digitos");
			return false;
		}
		if (txtEmailClientes.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo email");
			return false;
		}
		if (txtEnderecoClientes.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo endere�o");
			return false;
		}
		if (txtNumeroClientes.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo n�mero");
			return false;
		}		
		if (txtBairroClientes.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo bairro");
			return false;
		}
		if (cbxCidadeClientes.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo cidade");
			return false;
		}		
		if (txtCepClientes.getText().replace("-","").replace("_","").equals(""))
		{
			Biblioteca.trataErro("Preencha o campo cep");
			return false;
		}
		if (txtCepClientes.getText().replace("-","").replace("_","").length() < 8)
		{
			Biblioteca.trataErro("Preencha o campo cep com ao menos 8 digitos");
			return false;
		}
		return true;
	}

	//Preenche os campos da aba Produtos com um objeto ProdutoVO
	private void preecheCamposProdutos(ProdutoVO u){    
		if(!u.getId().equals(null)) {
			txtIDProdutos.setText(u.getId());
			String categoriaProdutos = u.getCategoriaID();
			ObservableList<String> items = cbxCategoriaProdutos.getItems();
			for(String item : items){
				if (item.toString().substring(0, item.toString().indexOf(' ')).equals(categoriaProdutos))
				{
					cbxCategoriaProdutos.getSelectionModel().select(item.toString());
				}
			}					
			txtDescricaoProdutos.setText(u.getDescricao());			 
			txtValorProdutos.setText(String.format("%.2f", (u.getValor())));	
			txtQuantidadeProdutos.setText(String.format("%.0f",u.getQuantidadeEstoque()));
			if (u.getInventario())
				cbxInventarioProdutos.getSelectionModel().select("Sim");
			else
				cbxInventarioProdutos.getSelectionModel().select("N�o");
		}
	}

	//Limpa campos da aba Produtos
	private void limpaCamposProdutos() {
		txtIDProdutos.setText("");
		cbxCategoriaProdutos.getSelectionModel().select("");
		txtDescricaoProdutos.setText("");
		txtValorProdutos.setText("");
		txtQuantidadeProdutos.setText("0");			
		cbxInventarioProdutos.getSelectionModel().select("");					
	}

	//Muda a aba Produtos para navega��o
	private void modoNavegacaoProdutos() {
		txtIDProdutos.setEditable(false);
		cbxCategoriaProdutos.setDisable(true);	
		txtDescricaoProdutos.setEditable(false);
		txtValorProdutos.setEditable(false);
		txtQuantidadeProdutos.setEditable(false);			
		cbxInventarioProdutos.setDisable(true);					
		btnIncluirProdutos.setDisable(false);		
		btnAlterarProdutos.setDisable(false);
		btnExcluirProdutos.setDisable(false);
		btnSalvarProdutos.setDisable(true);
		btnCancelarProdutos.setDisable(true);
		btnPrimeiroProdutos.setDisable(false);
		btnAnteriorProdutos.setDisable(false);
		btnProximoProdutos.setDisable(false);
		btnUltimoProdutos.setDisable(false);
		//btnPesquisarProdutos.setDisable(false);
		navegacaoProdutos = true;
		edicaoProdutos = false;
		abaUsuarios.setDisable(false);
		abaClientes.setDisable(false);
		abaProdutos.setDisable(false);
		abaPedidos.setDisable(false);
	}

	//Muda a aba Produtos para edi��o
	private void modoEdicaoProdutos() {
		txtIDProdutos.setEditable(false);
		cbxCategoriaProdutos.setDisable(false);	
		txtDescricaoProdutos.setEditable(true);
		txtValorProdutos.setEditable(true);
		//txtQuantidadeProdutos.setEditable(true);			
		cbxInventarioProdutos.setDisable(false);	
		if (cbxInventarioProdutos.getValue().toString().equals("Sim"))
			txtQuantidadeProdutos.setEditable(true);
		else
		{
			txtQuantidadeProdutos.setEditable(false);
			txtQuantidadeProdutos.setText("0");
		}
		btnIncluirProdutos.setDisable(true);		
		btnAlterarProdutos.setDisable(true);
		btnExcluirProdutos.setDisable(true);
		btnSalvarProdutos.setDisable(false);
		btnCancelarProdutos.setDisable(false);
		btnPrimeiroProdutos.setDisable(true);
		btnAnteriorProdutos.setDisable(true);
		btnProximoProdutos.setDisable(true);
		btnUltimoProdutos.setDisable(true);
		//btnPesquisarProdutos.setDisable(true);
		navegacaoProdutos = false;
		edicaoProdutos = true;
		abaUsuarios.setDisable(true);
		abaClientes.setDisable(true);
		abaProdutos.setDisable(false);
		abaPedidos.setDisable(true);
	}

	//Verificar campos da aba Produtos
	private boolean testaCamposProdutos() {
		if (txtDescricaoProdutos.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo descri��o");
			return false;
		}
		if (cbxCategoriaProdutos.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo categoria");
			return false;
		}		
		if (txtValorProdutos.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo valor");
			return false;
		}
		if (txtQuantidadeProdutos.getText().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo quantidade");
			return false;
		}
		if (cbxInventarioProdutos.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo inventario");
			return false;
		}			
		String decimalPattern = "([0-9]*)\\.([0-9]*)";
		String intPattern = "\\d+";  
		boolean match1 = Pattern.matches(decimalPattern, txtValorProdutos.getText().replace(",","."));
		boolean match2 = Pattern.matches(intPattern, txtValorProdutos.getText().replace(",","."));
		if (!match1 && !match2)
		{
			Biblioteca.trataErro("Valor do produto � inv�lido, o valor deve ser um inteiro ou decimal positivo");
			return false;
		}
		match2 = Pattern.matches(intPattern, txtQuantidadeProdutos.getText().replace(",","."));
		if (!match2)
		{
			Biblioteca.trataErro("Valor de quantidade � inv�lido, o valor deve ser um inteiro positivo");
			return false;
		}
		return true;
	}	
	//Preenche os campos da aba Pedidos com um objeto PedidoVO
	private void preecheCamposPedidos(PedidoVO u){    
		if(!u.getId().equals(null)) {			
			txtIDPedidos.setText(u.getId());
			String usuarioPedidos = u.getUsuarioID();
			ObservableList<String> items = cbxOperadorPedidos.getItems();
			for(String item : items){
				if (item.toString().substring(0, item.toString().indexOf(' ')).equals(usuarioPedidos))
				{
					cbxOperadorPedidos.getSelectionModel().select(item.toString());
				}
			}	
			String tipoPedidoPedidos = u.getTipoPedidoID();
			items = cbxTipoPedidoPedidos.getItems();
			for(String item : items){
				if (item.toString().substring(0, item.toString().indexOf(' ')).equals(tipoPedidoPedidos))
				{
					cbxTipoPedidoPedidos.getSelectionModel().select(item.toString());
				}
			}		
			if(u.getClienteID() != null){			
				String clientePedidos = u.getClienteID();
				items = cbxClientePedidos.getItems();
				for(String item : items){
					if (item.toString().substring(0, item.toString().indexOf(' ')).equals(clientePedidos))
					{
						cbxClientePedidos.getSelectionModel().select(item.toString());
					}
				}
			}
			else
			{
				cbxClientePedidos.getSelectionModel().select("");
			}
		}		
		SimpleDateFormat targetFormat = new SimpleDateFormat("dd-MM-YYYY");
		String date;		
		date = targetFormat.format(u.getData());		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate localDate = LocalDate.parse(date, formatter);
		dpkDataPedidos.setValue(localDate);			
		tabItensPedidoPedidos.getItems().clear();
		tabItensPedidoPedidos.getItems().addAll(u.getItensPedido());
		txtValorTotalPedidos.setText(String.format("%.2f",calculaValorTotalPedido()));	
		cbxProdutoPedidos.getSelectionModel().select("");	
	}

	//Limpa campos da aba Pedidos
	private void limpaCamposPedidos() {
		txtIDPedidos.setText("");
		cbxOperadorPedidos.getSelectionModel().select("");
		cbxTipoPedidoPedidos.getSelectionModel().select("");
		cbxClientePedidos.getSelectionModel().select("");		
		dpkDataPedidos.setValue(LocalDate.now());
		txtValorTotalPedidos.setText("");
		txtQuantidadeProdutoPedidos.setText("");
		cbxProdutoPedidos.getSelectionModel().select("");	
		tabItensPedidoPedidos.getItems().clear();
	}

	//Muda a aba Pedidos para navega��o
	private void modoNavegacaoPedidos() {
		txtIDPedidos.setEditable(false);
		cbxOperadorPedidos.setDisable(true);
		cbxTipoPedidoPedidos.setDisable(true);
		cbxClientePedidos.setDisable(true);
		dpkDataPedidos.setEditable(false);
		txtValorTotalPedidos.setEditable(false);						
		btnIncluirPedidos.setDisable(false);		
		btnAlterarPedidos.setDisable(false);
		btnExcluirPedidos.setDisable(false);
		btnSalvarPedidos.setDisable(true);
		btnCancelarPedidos.setDisable(true);
		btnPrimeiroPedidos.setDisable(false);
		btnAnteriorPedidos.setDisable(false);
		btnProximoPedidos.setDisable(false);
		btnUltimoPedidos.setDisable(false);
		//btnPesquisarPedidos.setDisable(false);
		cbxProdutoPedidos.setDisable(true);
		txtQuantidadeProdutoPedidos.setEditable(false);
		//btnPesquisarProdutoPedidos.setDisable(true);
		btnAdicionarProdutoPedidos.setDisable(true);
		btnExcluirProdutoPedidos.setDisable(true);
		navegacaoPedidos = true;
		edicaoPedidos = false;
		abaUsuarios.setDisable(false);
		abaClientes.setDisable(false);
		abaProdutos.setDisable(false);
		abaPedidos.setDisable(false);
	}

	//Muda a aba Pedidos para edi��o
	private void modoEdicaoPedidos() {
		txtIDPedidos.setEditable(false);
		cbxOperadorPedidos.setDisable(false);		
		cbxTipoPedidoPedidos.setDisable(false);
		if (cbxTipoPedidoPedidos.getValue().toString().substring(0, cbxTipoPedidoPedidos.getValue().toString().toString().indexOf(' ')).equals("2"))
			cbxClientePedidos.setDisable(false);
		else
		{
			cbxClientePedidos.setDisable(true);
			cbxClientePedidos.getSelectionModel().select("");
		}	
		dpkDataPedidos.setEditable(true);
		txtValorTotalPedidos.setEditable(false);						
		btnIncluirPedidos.setDisable(true);		
		btnAlterarPedidos.setDisable(true);
		btnExcluirPedidos.setDisable(true);
		btnSalvarPedidos.setDisable(false);
		btnCancelarPedidos.setDisable(false);
		btnPrimeiroPedidos.setDisable(true);
		btnAnteriorPedidos.setDisable(true);
		btnProximoPedidos.setDisable(true);
		btnUltimoPedidos.setDisable(true);
		//btnPesquisarPedidos.setDisable(true);
		cbxProdutoPedidos.setDisable(false);
		txtQuantidadeProdutoPedidos.setEditable(true);		
		//btnPesquisarProdutoPedidos.setDisable(false);
		btnAdicionarProdutoPedidos.setDisable(false);
		btnExcluirProdutoPedidos.setDisable(false);
		navegacaoPedidos = false;
		edicaoPedidos = true;
		abaUsuarios.setDisable(true);
		abaClientes.setDisable(true);
		abaProdutos.setDisable(true);
		abaPedidos.setDisable(false);
	}

	//Verificar campos da aba Pedidos
	private boolean testaCamposPedidos() {
		if (cbxOperadorPedidos.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo operador");
			return false;
		}		
		if (cbxTipoPedidoPedidos.getValue().toString().equals(""))
		{
			Biblioteca.trataErro("Preencha o campo tipo de pedido");
			return false;
		}		
		if (cbxClientePedidos.getValue().toString().equals("") && !cbxClientePedidos.isDisabled())
		{
			Biblioteca.trataErro("Preencha o campo cliente");
			return false;
		}		
		return true;
	}	
	
	//Verificar campos produto da aba Pedidos
		private boolean testaCamposProdutoPedidos() {
			if (cbxProdutoPedidos.getValue().toString().equals(""))
			{
				Biblioteca.trataErro("Selecione um produto");
				return false;
			}			
			String decimalPattern = "([0-9]*)\\.([0-9]*)";
			String intPattern = "\\d+";  
			boolean match1 = Pattern.matches(decimalPattern, txtQuantidadeProdutoPedidos.getText().replace(",","."));
			boolean match2 = Pattern.matches(intPattern, txtQuantidadeProdutoPedidos.getText().replace(",","."));
			if (!match1 && !match2)
			{
				Biblioteca.trataErro("Quantidade do produto � inv�lido, o valor deve ser um inteiro ou decimal positivo");
				return false;
			}
			return true;
		}	
	private double calculaValorTotalPedido() {
		double total = 0;
		pedidoTemp.setItensPedido(tabItensPedidoPedidos.getItems());
		for (ItemPedidoVO v:pedidoTemp.itensPedido)
		{
			total = total + Double.parseDouble(v.getValorTotal().replace(",", "."));
		}	
		return total;
	}
}