
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ItemPedidoDAO {
	//insere um novo Item do Pedido
	public static void insere(ItemPedidoVO itemPedido, Connection cx) throws Exception {		
		String sql = "insert into ItensPedido (pedido_ID, produto_ID, quantidade, valorUnitario)"
				+ " values (?,?,?,?)";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setInt(1, Integer.parseInt(itemPedido.getPedidoID()));
		p.setInt(2, Integer.parseInt(itemPedido.getProdutoID()));
		p.setDouble(3, itemPedido.getQuantidade());
		p.setDouble(4, itemPedido.getValorUnitario());		
		p.execute();
		p.close();
		//cx.close();
	}	

	//excluir um ItemPedido
	public static void excluir(String id) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "delete from ItensPedido where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		p.execute();
		p.close();
		cx.close();		
	}

	//consulta um ItemPedido pelo id    
	public static ItemPedidoVO consultaId(String id) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ItemPedidoVO u = new ItemPedidoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select * from ItensPedido where id = ?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaItemPedidoVO(rs);
		}			   
		return u; 
	}		

	//monta os dados do objeto ItemPedido
	public static ItemPedidoVO montaItemPedidoVO(ResultSet rs) throws Exception{
		ItemPedidoVO u = new ItemPedidoVO();
		u.setId(rs.getString("id"));
		u.setPedidoID(rs.getString("pedido_ID"));
		ProdutoVO p = new ProdutoVO();
		u.setProdutoID(rs.getString("produto_ID"));
		p = ProdutoDAO.consultaId(u.getProdutoID());
		u.setDescricao(p.getDescricao());
		u.setQuantidade(Double.parseDouble(rs.getString("quantidade")));
		u.setValorUnitario(Double.parseDouble(rs.getString("valorUnitario")));		
		return u;
	}
	
	//lista todos os itens do pedido cadastrados para o id indicado  
		public static ResultSet listaItensPedido(String id){              
			Connection cx = Biblioteca.ConexaoBD.getConexao();
			ResultSet rs = null;
			try {
				if(cx==null){
					throw new Exception("Erro na conex�o com o banco!!");
				}
				String sql ="select * from itensPedido where pedido_ID = ?";				
				PreparedStatement p = cx.prepareStatement(sql);
				p.setString(1, id);
				rs = p.executeQuery();                     
			}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
			catch(Exception ex){
				System.out.println(ex.getMessage());
			}	
			return rs;         
		}
}
