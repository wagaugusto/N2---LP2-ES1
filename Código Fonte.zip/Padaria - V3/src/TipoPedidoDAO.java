import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TipoPedidoDAO {
	//monta os dados do objeto tipoPedido
		public static TipoPedidoVO montaTipoPedidoVO(ResultSet rs){
			TipoPedidoVO f = new TipoPedidoVO();
			try {
				f.setId(rs.getString("id"));
				f.setNome(rs.getString("nome"));					
			}		
			catch(Exception ex){
				System.out.println(ex.getMessage());			
			}	
			return f;
		}
		
		 
	    //lista todos os tipos de usu�rios cadastrados  
	   public static ResultSet listaTiposPedido(){              
	       Connection cx = Biblioteca.ConexaoBD.getConexao();
	       ResultSet rs = null;
			try {
				if(cx==null){
					throw new Exception("Erro na conex�o com o banco!!");
				}
	           String sql ="select * from tiposPedido";
	           
	           PreparedStatement p = cx.prepareStatement(sql);
	           rs = p.executeQuery();                     
			}
	   		catch (SQLException ex) {
	   			ex.printStackTrace();
	   		}
	   		catch(Exception ex){
	   			System.out.println(ex.getMessage());
	   		}	
	   		return rs;         
	   }

}
