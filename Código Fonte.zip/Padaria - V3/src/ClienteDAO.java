
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {
	//insere um novo cliente
	public static void insere(ClienteVO cliente) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "insert into clientes (nome, telefone, email, endereco, numero, complemento, bairro, cidade_id, cep) values (?,?,?,?,?,?,?,?,?)";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, cliente.getNome());
		p.setString(2, cliente.getTelefone());
		p.setString(3, cliente.getEmail());
		p.setString(4, cliente.getEndereco());
		p.setString(5, cliente.getNumero());
		p.setString(6, cliente.getComplemento());
		p.setString(7, cliente.getBairro());
		p.setInt(8, Integer.parseInt(cliente.getCidade_ID()));		
		p.setString(9, cliente.getCep());		
		p.execute();
		p.close();
		cx.close();
	}

	//altera os dados de um cliente
	public static void alterar(ClienteVO cliente) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "update clientes set nome=?, telefone=?, email=?, "
				+ "endereco=?, numero=?, complemento=?, bairro=?, cidade_ID=?, cep=? where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, cliente.getNome());
		p.setString(2, cliente.getTelefone());
		p.setString(3, cliente.getEmail());
		p.setString(4, cliente.getEndereco());
		p.setString(5, cliente.getNumero());
		p.setString(6, cliente.getComplemento());
		p.setString(7, cliente.getBairro());
		p.setInt(8, Integer.parseInt(cliente.getCidade_ID()));		
		p.setString(9, cliente.getCep());
		p.setInt(10, Integer.parseInt(cliente.getId()));
		p.execute();
		p.close();
		cx.close();
	}

	//excluir um cliente
	public static void excluir(String id) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "delete from clientes where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		p.execute();
		p.close();
		cx.close();		
	}

	//consulta um cliente pelo id    
	public static ClienteVO consultaId(String id) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ClienteVO u = new ClienteVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select * from clientes where id = ?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaClienteVO(rs);
		}			   
		return u; 
	}	

	//consulta o primeiro cliente cadastrado
	public static ClienteVO primeiro() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ClienteVO u = new ClienteVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from clientes order by id";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaClienteVO(rs);
		}			   
		return u; 
	}

	//consulta o �ltimo cliente cadastrado
	public static ClienteVO ultimo() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ClienteVO u = new ClienteVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from clientes order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaClienteVO(rs);
		}			   
		return u; 
	}

	//consulta o cliente anterior
	public static ClienteVO anterior(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ClienteVO u = new ClienteVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from clientes where id < ? order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaClienteVO(rs);
		}			   
		return u; 
	}

	//consulta o pr�ximo cliente
	public static ClienteVO proximo(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ClienteVO u = new ClienteVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from clientes where id > ? order by id";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaClienteVO(rs);
		}			   
		return u; 
	}

	//monta os dados do objeto cliente
	public static ClienteVO montaClienteVO(ResultSet rs) throws SQLException{
		ClienteVO u = new ClienteVO();
		u.setId(rs.getString("id"));
		u.setNome(rs.getString("nome"));
		u.setTelefone(rs.getString("telefone"));
		u.setEmail(rs.getString("email"));
		u.setEndereco(rs.getString("endereco"));
		u.setNumero(rs.getString("numero"));
		u.setComplemento(rs.getString("complemento"));
		u.setBairro(rs.getString("bairro"));
		u.setCidade_ID(rs.getString("cidade_id"));
		u.setCep(rs.getString("cep"));	
		return u;
	}
	//lista todos os clientes cadastrados  
	public static ResultSet listaClientes(){              
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ResultSet rs = null;
		try {
			if(cx==null){
				throw new Exception("Erro na conex�o com o banco!!");
			}
			String sql ="select * from Clientes";

			PreparedStatement p = cx.prepareStatement(sql);
			rs = p.executeQuery();                     
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}	
		return rs;         
	}
}
