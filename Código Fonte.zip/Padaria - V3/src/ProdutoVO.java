
public class ProdutoVO {
	private String id;
	private String categoriaID;
	private String descricao;
    private double valor;
    private String caminhoFoto;
    private double quantidadeEstoque;
    private boolean inventario;
    
    public ProdutoVO() {

    }

    public ProdutoVO(String id, String categoriaID, String descricao, double valor, String caminhoFoto,
    		double quantidadeEstoque, boolean inventario) {
        super();
        this.id = id;
        this.categoriaID = categoriaID;
        this.descricao = descricao;
        this.valor = valor;
        this.caminhoFoto = caminhoFoto;
        this.quantidadeEstoque = quantidadeEstoque;
        this.inventario = inventario;        
    }
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCategoriaID() {
		return categoriaID;
	}
	public void setCategoriaID(String categoriaID) {
		this.categoriaID = categoriaID;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getCaminhoFoto() {
		return caminhoFoto;
	}
	public void setCaminhoFoto(String caminhoFoto) {
		this.caminhoFoto = caminhoFoto;
	}
	public double getQuantidadeEstoque() {
		return quantidadeEstoque;
	}
	public void setQuantidadeEstoque(double quantidadeEstoque) {
		this.quantidadeEstoque = quantidadeEstoque;
	}
	public boolean getInventario() {
		return inventario;
	}
	public void setInventario(boolean inventario) {
		this.inventario = inventario;
	}  
    
    
}
