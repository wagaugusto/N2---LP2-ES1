public class ItemPedidoVO {
	private String id;
	private String pedidoID;
	private String descricao;
	private String produtoID;
	private double quantidade;		
	private double valorUnitario;

	public ItemPedidoVO() {

	}

	public ItemPedidoVO(String id, String pedidoID, String produtoID, double quantidade,
			double valorUnitario) {
		super();
		this.id = id;
		this.pedidoID = pedidoID;
		this.produtoID = produtoID;
		this.quantidade = quantidade;        
		this.valorUnitario = valorUnitario;                
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPedidoID() {
		return pedidoID;
	}
	public void setPedidoID(String pedidoID) {
		this.pedidoID = pedidoID;
	}
	public String getProdutoID() {
		return produtoID;
	}
	public void setProdutoID(String produtoID) {
		this.produtoID = produtoID;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(double quantidade) {
		this.quantidade = quantidade;
	}
	public double getValorUnitario() {
		return valorUnitario;
	}
	public void setValorUnitario(double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	//Quantidade formatado
	public String getQuantidadeFormatado() {
		return String.format("%.2f",quantidade);
	}
	//Valor unit�rio formatado
	public String getValorUnitarioFormatado() {
		return String.format("%.2f",valorUnitario);
	}
	//Valor calculado, n�o existe esta coluna no banco
	public String getValorTotal() {
		return String.format("%.2f",quantidade * valorUnitario);
	}
}
