import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PedidoVO {
	private String id;
	private String usuarioID;
	private String tipoPedidoID;
	private String clienteID;
	private Date data;
	private double valorTotal;
	List<ItemPedidoVO> itensPedido = new ArrayList<>();
	
	public PedidoVO() {

    }

    public PedidoVO(String id, String usuarioID, String tipoPedidoID, String clienteID,
    		Date data, double valorTotal) {
        super();
        this.id = id;
        this.usuarioID = usuarioID;
        this.tipoPedidoID = tipoPedidoID;
        this.clienteID = clienteID;
        this.data = data;
        this.valorTotal = valorTotal;                
    }
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsuarioID() {
		return usuarioID;
	}
	public void setUsuarioID(String usuarioID) {
		this.usuarioID = usuarioID;
	}
	public String getTipoPedidoID() {
		return tipoPedidoID;
	}
	public void setTipoPedidoID(String tipoPedidoID) {
		this.tipoPedidoID = tipoPedidoID;
	}
	public String getClienteID() {
		return clienteID;
	}
	public void setClienteID(String clienteID) {
		this.clienteID = clienteID;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public List<ItemPedidoVO> getItensPedido() {
		return itensPedido;
	}

	public void setItensPedido(List<ItemPedidoVO> itensPedido) {
		this.itensPedido = itensPedido;
	}
}
