import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {
	//insere um novo usu�rio
	public static void insere(UsuarioVO usuario) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "insert into Usuarios (nome, telefone, email, funcao, tipoUsuario, login, senha) values (?,?,?,?,?,?,?)";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, usuario.getNome());
		p.setString(2, usuario.getTelefone());
		p.setString(3, usuario.getEmail());
		p.setInt(4, Integer.parseInt(usuario.getFuncao()));
		p.setInt(5, Integer.parseInt(usuario.getTipoUsuario()));
		p.setString(6, usuario.getLogin());
		p.setString(7, usuario.getSenha());
		p.execute();
		p.close();
		cx.close();
	}

	//altera os dados de um usu�rio
	public static void alterar(UsuarioVO usuario) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "update usuarios set nome=?, telefone=?, email=?, "
				+ "funcao=?, tipoUsuario=?, login=?, senha=? where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, usuario.getNome());
		p.setString(2, usuario.getTelefone());
		p.setString(3, usuario.getEmail());
		p.setInt(4, Integer.parseInt(usuario.getFuncao()));
		p.setInt(5, Integer.parseInt(usuario.getTipoUsuario()));
		p.setString(6, usuario.getLogin());
		p.setString(7, usuario.getSenha());
		p.setInt(8, Integer.parseInt(usuario.getId()));
		p.execute();
		p.close();
		cx.close();
	}

	//excluir um usu�rio
	public static void excluir(String id) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "delete from usuarios where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		p.execute();
		p.close();
		cx.close();		
	}

	//consulta um usu�rio pelo id    
	public static UsuarioVO consultaId(String id) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		UsuarioVO u = new UsuarioVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select * from usuarios where id = ?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaUsuarioVO(rs);
		}			   
		return u; 
	}

	//consulta um usu�rio pelo login  
	public static UsuarioVO consultaLogin(String login) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		UsuarioVO u = new UsuarioVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select * from usuarios where login = ?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, login);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaUsuarioVO(rs);
		}			   
		return u; 
	}

	//consulta o primeiro usu�rio cadastrado
	public static UsuarioVO primeiro() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		UsuarioVO u = new UsuarioVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from usuarios order by id";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaUsuarioVO(rs);
		}			   
		return u; 
	}

	//consulta o �ltimo usu�rio cadastrado
	public static UsuarioVO ultimo() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		UsuarioVO u = new UsuarioVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from usuarios order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaUsuarioVO(rs);
		}			   
		return u; 
	}

	//consulta o usu�rio anterior
	public static UsuarioVO anterior(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		UsuarioVO u = new UsuarioVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from usuarios where id < ? order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaUsuarioVO(rs);
		}			   
		return u; 
	}

	//consulta o pr�ximo usu�rio
	public static UsuarioVO proximo(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		UsuarioVO u = new UsuarioVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from usuarios where id > ? order by id";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaUsuarioVO(rs);
		}			   
		return u; 
	}

	//monta os dados do objeto usuario
	public static UsuarioVO montaUsuarioVO(ResultSet rs) throws SQLException{
		UsuarioVO u = new UsuarioVO();
		u.setId(rs.getString("id"));
		u.setNome(rs.getString("nome"));
		u.setTelefone(rs.getString("telefone"));
		u.setEmail(rs.getString("email"));
		u.setFuncao(rs.getString("funcao"));
		u.setTipoUsuario(rs.getString("tipoUsuario"));
		u.setLogin(rs.getString("login"));
		u.setSenha(rs.getString("senha"));		
		return u;
	}
	
	 //lista todos os usu�rios cadastrados  
	   public static ResultSet listaUsuarios(){              
	       Connection cx = Biblioteca.ConexaoBD.getConexao();
	       ResultSet rs = null;
			try {
				if(cx==null){
					throw new Exception("Erro na conex�o com o banco!!");
				}
	           String sql ="select * from Usuarios";
	           
	           PreparedStatement p = cx.prepareStatement(sql);
	           rs = p.executeQuery();                     
			}
	   		catch (SQLException ex) {
	   			ex.printStackTrace();
	   		}
	   		catch(Exception ex){
	   			System.out.println(ex.getMessage());
	   		}	
	   		return rs;         
	   }
}
