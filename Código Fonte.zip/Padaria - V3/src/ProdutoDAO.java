
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProdutoDAO {
	//insere um novo Produto
	public static void insere(ProdutoVO produto) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "insert into Produtos (categoria_ID, descricao, valor, caminhoFoto, quantidadeEstoque,"
				+ " inventario) values (?,?,?,?,?,?)";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setInt(1, Integer.parseInt(produto.getCategoriaID()));
		p.setString(2, produto.getDescricao());
		p.setDouble(3, produto.getValor());
		p.setString(4, produto.getCaminhoFoto());		
		p.setDouble(5, produto.getQuantidadeEstoque());		
		p.setBoolean(6, produto.getInventario());		
		p.execute();
		p.close();
		cx.close();
	}

	//altera os dados de um Produto
	public static void alterar(ProdutoVO produto) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "update Produtos set categoria_ID=?, descricao=?, valor=?, "
				+ "caminhoFoto=?, quantidadeEstoque=?, inventario=? where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setInt(1, Integer.parseInt(produto.getCategoriaID()));
		p.setString(2, produto.getDescricao());
		p.setDouble(3, produto.getValor());
		p.setString(4, produto.getCaminhoFoto());		
		p.setDouble(5, produto.getQuantidadeEstoque());		
		p.setBoolean(6, produto.getInventario());		
		p.setInt(7, Integer.parseInt(produto.getId()));
		p.execute();
		p.close();
		cx.close();
	}

	//excluir um Produto
	public static void excluir(String id) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "delete from Produtos where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		p.execute();
		p.close();
		cx.close();		
	}

	//consulta um Produto pelo id    
	public static ProdutoVO consultaId(String id) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ProdutoVO u = new ProdutoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select * from Produtos where id = ?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaProdutoVO(rs);
		}			   
		return u; 
	}	

	//consulta o primeiro Produto cadastrado
	public static ProdutoVO primeiro() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ProdutoVO u = new ProdutoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Produtos order by id";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaProdutoVO(rs);
		}			   
		return u; 
	}

	//consulta o �ltimo Produto cadastrado
	public static ProdutoVO ultimo() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ProdutoVO u = new ProdutoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Produtos order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaProdutoVO(rs);
		}			   
		return u; 
	}

	//consulta o Produto anterior
	public static ProdutoVO anterior(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ProdutoVO u = new ProdutoVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Produtos where id < ? order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaProdutoVO(rs);
		}			   
		return u; 
	}

	//consulta o pr�ximo Produto
	public static ProdutoVO proximo(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ProdutoVO u = new ProdutoVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Produtos where id > ? order by id";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaProdutoVO(rs);
		}			   
		return u; 
	}

	//monta os dados do objeto Produto
	public static ProdutoVO montaProdutoVO(ResultSet rs) throws SQLException{
		ProdutoVO u = new ProdutoVO();
		u.setId(rs.getString("id"));
		u.setCategoriaID(rs.getString("categoria_ID"));
		u.setDescricao(rs.getString("descricao"));
		u.setValor(Double.parseDouble(rs.getString("valor")));
		u.setCaminhoFoto(rs.getString("caminhoFoto"));
		u.setQuantidadeEstoque(Double.parseDouble(rs.getString("quantidadeEstoque")));
		if ((rs.getString("inventario").equals("0")))
			u.setInventario(false);
		else
			u.setInventario(true);
		return u;
	}

	//lista todos os produtos cadastrados  
	public static ResultSet listaProdutos(){              
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		ResultSet rs = null;
		try {
			if(cx==null){
				throw new Exception("Erro na conex�o com o banco!!");
			}
			String sql ="select * from Produtos";

			PreparedStatement p = cx.prepareStatement(sql);
			rs = p.executeQuery();                     
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}	
		return rs;         
	}
}
