
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

public class PedidoDAO {
	//insere um novo Pedido
	public static void insere(PedidoVO pedido) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		cx.setAutoCommit(false);
		String sql = "insert into Pedidos (usuario_ID, tipoPedido_ID, cliente_ID, data, valorTotal)"
				+ " values (?,?,?,?,?)";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setInt(1, Integer.parseInt(pedido.getUsuarioID()));
		p.setInt(2, Integer.parseInt(pedido.getTipoPedidoID()));
		if (pedido.getClienteID().equals(""))
			p.setNull(3, Types.INTEGER);
		else
			p.setInt(3, Integer.parseInt(pedido.getClienteID()));		
		p.setDate(4, new java.sql.Date(pedido.getData().getTime()));
		p.setDouble(5, pedido.getValorTotal());		
		p.execute();
		p.close();
		sql = "select ident_current('Pedidos') as id";
		p = cx.prepareStatement(sql);		
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			pedido.setId(rs.getString(1));
		}	
		p.close();		
		for (ItemPedidoVO v:pedido.itensPedido)
		{
			v.setPedidoID(pedido.getId());
			ItemPedidoDAO.insere(v, cx);
		}	
		cx.commit();
		cx.close();
	}

	//altera os dados de um Pedido
	public static void alterar(PedidoVO pedido) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		cx.setAutoCommit(false);
		//primeira query
		String sql = "update Pedidos set usuario_ID=?, tipoPedido_ID=?, cliente_ID=?, "
				+ "data=?, valorTotal=? where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setInt(1, Integer.parseInt(pedido.getUsuarioID()));
		p.setInt(2, Integer.parseInt(pedido.getTipoPedidoID()));
		if (pedido.getClienteID().equals(""))
			p.setNull(3, Types.INTEGER);
		else
			p.setInt(3, Integer.parseInt(pedido.getClienteID()));		
		p.setDate(4, new java.sql.Date(pedido.getData().getTime()));
		p.setDouble(5, pedido.getValorTotal());	
		p.setInt(6, Integer.parseInt(pedido.getId()));
		p.execute();
		p.close();
		//segunda query
		sql = "delete from itensPedido where pedido_id=?";
		p = cx.prepareStatement(sql);
		p.setInt(1, Integer.parseInt(pedido.getId()));
		p.execute();		
		p.close();		
		for (ItemPedidoVO v:pedido.itensPedido)
		{
			v.setPedidoID(pedido.getId());
			ItemPedidoDAO.insere(v, cx);
		}	
		cx.commit();
		cx.close();
	}

	//excluir um Pedido
	public static void excluir(String id) throws Exception {
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql = "delete from Pedidos where id=?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		p.execute();
		p.close();
		cx.close();		
	}

	//consulta um Pedido pelo id    
	public static PedidoVO consultaId(String id) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		PedidoVO u = new PedidoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select * from Pedidos where id = ?";
		PreparedStatement p = cx.prepareStatement(sql);
		p.setString(1, id);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaPedidoVO(rs);
		}			   
		return u; 
	}	

	//consulta o primeiro Pedido cadastrado
	public static PedidoVO primeiro() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		PedidoVO u = new PedidoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Pedidos order by id";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaPedidoVO(rs);
		}			   
		return u; 
	}

	//consulta o �ltimo Pedido cadastrado
	public static PedidoVO ultimo() throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		PedidoVO u = new PedidoVO();
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Pedidos order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);			
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaPedidoVO(rs);
		}			   
		return u; 
	}

	//consulta o Pedido anterior
	public static PedidoVO anterior(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		PedidoVO u = new PedidoVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Pedidos where id < ? order by id desc";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaPedidoVO(rs);
		}			   
		return u; 
	}

	//consulta o pr�ximo Pedido
	public static PedidoVO proximo(String atual) throws Exception{
		Connection cx = Biblioteca.ConexaoBD.getConexao();
		PedidoVO u = new PedidoVO();
		u = null;
		if(cx==null){
			throw new Exception("Erro na conex�o com o banco!!");
		}
		String sql ="select top 1 * from Pedidos where id > ? order by id";
		PreparedStatement p = cx.prepareStatement(sql);	
		p.setString(1, atual);
		ResultSet rs = p.executeQuery();
		if(rs.next()){
			u = montaPedidoVO(rs);
		}			   
		return u; 
	}

	//monta os dados do objeto Pedido
	private static PedidoVO montaPedidoVO(ResultSet rs) throws Exception{
		PedidoVO u = new PedidoVO();
		u.setId(rs.getString("id"));
		u.setUsuarioID(rs.getString("usuario_ID"));
		u.setTipoPedidoID(rs.getString("tipoPedido_ID"));
		u.setClienteID(rs.getString("cliente_ID"));
		u.setData(Date.valueOf(rs.getString("data")));
		u.setValorTotal(Double.parseDouble(rs.getString("valorTotal")));	
		rs = ItemPedidoDAO.listaItensPedido(u.getId());
		while(rs.next()){
			ItemPedidoVO f = ItemPedidoDAO.montaItemPedidoVO(rs);
			u.itensPedido.add(f);				
		}
		return u;
	}
}
